<?php
/**
 * @package Disable Default Dashboard Widgets
 */
/*

Plugin Name: Disable Default Dashboard Widgets
Plugin URI: https://devles.com/
Description: This is Default Dashboard Widgets Removal 
Author: Rezwan Shiblu
Author URI: https://devles.com/
Version: 1.0
License: GPLv2 or later
Text Domain: Disable Default Dashboard Widgets
*/


/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Rezwan,Sylhet, Bangladesh.

Copyright 2020.
*/


//Disable Default Dashboard Widgets
function remove_dashboard_meta() {
    remove_meta_box('welcome-panel', 'dashboard', 'normal'); //Removes the 'incoming links' widget
    remove_meta_box('dashboard_incoming_links', 'dashboard', 'normal'); //Removes the 'incoming links' widget
    remove_meta_box('dashboard_plugins', 'dashboard', 'normal'); //Removes the 'plugins' widget
    remove_meta_box('dashboard_primary', 'dashboard', 'normal'); //Removes the 'WordPress News' widget
    remove_meta_box('dashboard_secondary', 'dashboard', 'normal'); //Removes the secondary widget
    remove_meta_box('dashboard_quick_press', 'dashboard', 'side'); //Removes the 'Quick Draft' widget
    remove_meta_box('dashboard_recent_drafts', 'dashboard', 'side'); //Removes the 'Recent Drafts' widget
    remove_meta_box('dashboard_recent_comments', 'dashboard', 'normal'); //Removes the 'Activity' widget
    remove_meta_box('dashboard_right_now', 'dashboard', 'normal'); //Removes the 'At a Glance' widget
    remove_meta_box('dashboard_activity', 'dashboard', 'normal'); //Removes the 'Activity' widget (since 3.8)
    remove_meta_box('rg_forms_dashboard', 'dashboard', 'normal'); //Removes the 'Activity' widget (since 3.8)
    remove_action('admin_notices', 'update_nag');
}
add_action('admin_init', 'remove_dashboard_meta');


